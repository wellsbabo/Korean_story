//package com.example.korean_story;
//
//
//import android.os.Message;
//import android.os.Handler;
//
//public class IntroThread extends Thread{
//
//    private Handler handler;
//
//    public IntroThread(Handler handler){    //Thread.sleep() 메소드를 종료했을 때 메시지를 전달받기 위한 핸들러
//        this.handler = handler;
//    }
//
//    @Override
//    public void run(){  //다른 액티비티 또는 클래스에서 쓰레드 객체를 생성해 start()매소드를 호출했을 때 실행되는 메소드
//        Message msg  = new Message();
//
//        try{
//            Thread.sleep(3000);
//            msg.what = 1;
//            handler.sendEmptyMessage(msg.what);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//    }
//}