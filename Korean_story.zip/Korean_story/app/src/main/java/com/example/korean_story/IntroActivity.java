//package com.example.korean_story;
//
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.Message;
//import android.content.Intent;
////import android.support.v4.app.A
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class IntroActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState){
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_intro);
//
//        IntroThread introThread = new IntroThread(handler);
//        introThread.start();
//    }
//
//    public class Handler{
//        @Override
//        public void handleMessage(Message msg){
//            if(msg.what==1){
//                Intent intent = new Intent(IntroActivity.this, MainActivity.class);
//                startActivity(intent);
//            }
//        }
//    };
//
//    Handler handler = new Handler();
//
//}
